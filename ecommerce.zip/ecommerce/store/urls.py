from django.urls import path
from . import views

urlpatterns = [
    path('', views.storehome, name="storehome"),
    path('login/', views.login, name="login"),
    path('signup/', views.signup, name="signup"),
    path('logout/', views.logout, name="logout"),
    path('cart/', views.cart, name="cart"),
    path('checkout/', views.checkout, name="checkout"),
    path('order/', views.orderpage, name="order"),
    path('home/', views.homePage, name="home"),
    path('search/', views.search, name="search"),
    path('bloghome/', views.bloghome,name="bloghome"),
    #path('blogpost/', views.blogpost,name="blogpost"),
    path("bloghome/blogpost/<int:id>", views.blogpost, name="blogpost"),
    path('contact/', views.contact,name="contact"),
    path('about/', views.about,name="about"),
    path('billpay/', views.billpay,name="billpay"),
   

]